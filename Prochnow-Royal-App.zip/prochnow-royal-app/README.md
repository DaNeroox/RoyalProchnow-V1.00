# Prochnow Royal als App

Spielautomat mit Spielgeld. Alles steckt in `www/`, es wird kein Server und keine API gebraucht.

## 1. Sofort spielen (ohne Installation)
`www/index.html` doppelklicken. Läuft komplett lokal, auch offline.

## 2. Als App auf dem Handy oder PC installieren (empfohlen)
Browser erlauben die Installation nur über HTTPS oder `localhost`.

**Variante A: kostenlos online stellen**
1. Den Ordner `www` auf https://app.netlify.com/drop ziehen (oder GitHub Pages / Cloudflare Pages nutzen).
2. Die erhaltene Adresse auf dem Handy öffnen.
3. Android (Chrome): Menü, dann „App installieren“. iPhone (Safari): Teilen, dann „Zum Home-Bildschirm“.

**Variante B: lokal auf dem PC**
1. Windows: `start-lokal.bat` doppelklicken. Mac/Linux: `start-lokal.sh` ausführen. (Python muss installiert sein.)
2. Im Chrome oder Edge erscheint in der Adressleiste das Symbol „Installieren“.

Danach startet das Spiel im Vollbild mit eigenem Symbol und läuft offline.

## 3. Android-App (APK) bauen

**Variante A: automatisch bei GitHub (ohne Android Studio, kostenlos)**
1. Bei github.com ein neues Repository anlegen und den gesamten Inhalt dieses Ordners hochladen. Der versteckte Ordner `.github` muss mit hoch.
2. Im Repository auf „Actions“, dann „APK bauen“, dann „Run workflow“ klicken.
3. Nach ein paar Minuten steht beim fertigen Lauf unten unter „Artifacts“ die Datei **Prochnow-Royal-APK**. Das ZIP entpacken, darin liegt `app-debug.apk`.
4. Die APK aufs Android-Handy kopieren und öffnen. Android fragt einmal, ob Installationen aus dieser Quelle erlaubt sind.

**Variante B: online ohne eigenes Entwicklungswerkzeug**
1. `www` auf https://app.netlify.com/drop hochladen.
2. Die Adresse auf https://www.pwabuilder.com eingeben und „Package for stores“, dann „Android“ wählen.

**Variante C: lokal mit Android Studio**
Voraussetzung: Node.js und Android Studio.

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

In Android Studio „Build, Build APK(s)“ wählen.

Die so gebaute APK ist eine Debug-Version zum Installieren auf eigenen Geräten und trägt das Standard-Symbol von Capacitor. Für den Play Store brauchst du zusätzlich ein Entwicklerkonto und eine signierte Release-Version. Für iOS entsprechend `@capacitor/ios` und Xcode nutzen.

## Hinweise
- Spielstand, Guthaben und Soundauswahl werden im Browser bzw. in der App gespeichert.
- Nach Änderungen an Dateien in `www/` in `sw.js` die Zahl bei `prochnow-royal-v1` erhöhen, damit installierte Apps die neue Version laden.
