# Prochnow Royal als App

Spielautomat mit Spielgeld. Alles steckt in `www/`, es wird kein Server und keine API gebraucht.

## 1. Sofort spielen (ohne Installation)
`www/index.html` doppelklicken. Läuft komplett lokal, auch offline.

## 2. Als App auf dem Handy oder PC installieren (empfohlen)
Browser erlauben die Installation nur über HTTPS oder `localhost`.

**Variante A: kostenlos online stellen**
1. Den Ordner `www` auf https://app.netlify.com/drop ziehen (oder GitHub Pages / Cloudflare Pages nutzen).
2. Die erhaltene Adresse auf dem Handy öffnen.
3. Android (Chrome): Menü, dann „App installieren“. iPhone (Safari): Teilen, dann „Zum Home-Bildschirm“.

**Variante B: lokal auf dem PC**
1. Windows: `start-lokal.bat` doppelklicken. Mac/Linux: `start-lokal.sh` ausführen. (Python muss installiert sein.)
2. Im Chrome oder Edge erscheint in der Adressleiste das Symbol „Installieren“.

Danach startet das Spiel im Vollbild mit eigenem Symbol und läuft offline.

## 3. Android-App (APK) bauen
Voraussetzung: Node.js und Android Studio.

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

In Android Studio dann „Build, Build APK(s)“ wählen. Für den Play Store brauchst du zusätzlich ein Entwicklerkonto und eine signierte App.
Für iOS entsprechend `@capacitor/ios` und Xcode nutzen.

## Hinweise
- Spielstand, Guthaben und Soundauswahl werden im Browser bzw. in der App gespeichert.
- Nach Änderungen an Dateien in `www/` in `sw.js` die Zahl bei `prochnow-royal-v1` erhöhen, damit installierte Apps die neue Version laden.
