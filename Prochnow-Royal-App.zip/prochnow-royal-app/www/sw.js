// Prochnow Royal – Service Worker
// Spiel-Seite: zuerst Internet (immer neueste Version), ohne Netz aus dem Speicher.
const CACHE='prochnow-royal-v13';
const FILES=['./','index.html','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/icon-maskable-512.png','icons/apple-touch-icon.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const req=e.request;
  if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(url.origin!==location.origin)return;
  const isPage=req.mode==='navigate'||url.pathname.endsWith('.html')||url.pathname.endsWith('/')||url.pathname.endsWith('.webmanifest');
  if(isPage){
    e.respondWith(
      fetch(req,{cache:'no-store'}).then(r=>{
        if(r&&r.ok){const c1=r.clone(),c2=r.clone();caches.open(CACHE).then(x=>{x.put(req,c1);if(req.mode==='navigate'){x.put('index.html',c2);}})}
        return r;
      }).catch(()=>caches.match(req).then(r=>r||caches.match('index.html')))
    );
    return;
  }
  e.respondWith(caches.match(req).then(r=>r||fetch(req).then(n=>{if(n&&n.ok){const c=n.clone();caches.open(CACHE).then(x=>x.put(req,c))}return n})));
});
